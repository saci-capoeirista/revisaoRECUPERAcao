const prompt = require('prompt-sync')();
let data = require('./data');
const adicionarCliente = require('./adicionarCliente');
const adicionarServico = require('./adicionarServico');
const listarAgendamento = require('./listarAgendamento');
const listarClientes = require('./listarClientes')




menu();
function menu() {

    console.log(`
1. Cadastrar um novo cliente $
2. Cadastrar um novo serviço  $
3. Agendar um serviço para um cliente 
4. Listar todos os clientes $
5. listar Agendamentos por id de cliente $
6. Atualizar as informações de um agendamento
7. Remover um cliente
8. Remover um serviço
9. Remover um agendamento
0. Sair
`);

    let opcao = prompt('Escolha uma opção para prosseguir: ');
    let index;

    switch (opcao) {
        case '1':
            let nome = prompt('Nome do cliente para cadastrar: ');
            let cpf = prompt('Cpf do cliente para cadastrar: ');
            let telefone = prompt('Telefone do cliente para cadastrar: ');
            let email = prompt('Email do cliente para cadastrar: ');
            adicionarCliente(({ nome, cpf, telefone, email }));
            menu();
            break;
        case '2':
            let servico = prompt('Adicione um serviço: ');
            let preco = parseFloat(prompt('Adicione o preço: '));
            adicionarServico(({ servico, preco }));
            menu();
            break;
        case '3':
            data.servicos.forEach(servico => {
                console.log(`ID:${servico.id}, Tipo do serviço: ${servico.nomeServico}, preço: R$${servico.preco}`);
            })
            let cadServico = prompt('Qual serviço quer agendar?: ');
            listarClientes();
            let servCliente = prompt('Para qual cliente?(Digite o ID): ');
            agendarServico(({cadServico, servCliente}))
            menu();
            break;
        case '4':
            if (data.clientes === 0) {
                console.log('NADA encontrado!!');
            } else {
                listarClientes();
                menu();
                break;
            }
        case '5':
            if (data.clientes === 0) {
                console.log('NADA encontrado!!');
            } else {
                data.clientes.forEach(cliente => {
                    console.log(`${cliente.id}. ${cliente.nome}`)
                });
                let idCliente = prompt('Digite o id do cliente: ');
                listarAgendamento(idCliente);
                menu();
                break;
            }
    }
}

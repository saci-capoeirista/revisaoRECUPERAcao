function agendarServico(cadServico, servCliente) {
    clientes.filter(clientes => clientes.id === idCliente).forEach(cliente => {

    })
}
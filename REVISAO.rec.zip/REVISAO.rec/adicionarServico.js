let data = require('./data');

function adicionarServico(servico) {
    servico.id = data.servicos.length + 1;
    let jaExiste = data.servicos.find(svç => svç.nomeServico === data.servicos.nomeServico);
    if (jaExiste) {
        console.log('Email ;já existente!');
    } else {
        data.servicos.push(servico);
        console.log('Adicionado com sucesso!!');
    }
}
module.exports = adicionarServico;
let {clientes} = require('./data');

function listarAgendamento(idCliente) {
    clientes.filter(cliente => cliente.id === idCliente).forEach(cliente => {
        console.log(`ID:${cliente.id} nome: ${cliente.nome}, 
cpf:${cliente.cpf}, telefone:${cliente.telefone}, email:${cliente.email}`)
    })
}

module.exports = listarAgendamento;
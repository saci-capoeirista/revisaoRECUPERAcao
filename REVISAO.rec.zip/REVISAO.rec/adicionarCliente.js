let data = require('./data');

function adicionarCliente(cliente) {
    cliente.id = data.clientes.length + 1;
    let jaExiste = data.clientes.find(clt => clt.email === data.clientes.email);
    if (jaExiste) {
        console.log('Email ;já existente!');
    } else {
        data.clientes.push(cliente);
        console.log('Adicionado com sucesso!');
    }
}

module.exports = adicionarCliente;
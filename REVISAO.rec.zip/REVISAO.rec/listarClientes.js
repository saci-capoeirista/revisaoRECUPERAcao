let {clientes} = require('./data');

function listarClientes() {
    clientes.forEach(cliente => {
            console.log(`ID:${cliente.id}, nome: ${cliente.nome}, cpf:${cliente.cpf}, telefone:${cliente.telefone}, email:${cliente.email}`)
    })
}

module.exports = listarClientes;
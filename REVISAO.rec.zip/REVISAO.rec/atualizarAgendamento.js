const { agendamentos } = require('./data')

function atualizarAgendamento() {

}
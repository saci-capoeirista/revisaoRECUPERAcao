let clientes = [
    { id: 1, nome: 'Carlos', cpf: '213123-123213', telefone: '(42)9999990999', email: 'carlos@example.com', }
]

let servicos = [
    { id: 1, nomeServico: 'americano', preco: 'R$25,00', }
]

let agendamentos = [
    { id: 1, data: '2024-09-01', horario: '13:00', idCliente: 1, idServico: 1, }
]

module.exports = { clientes, servicos, agendamentos }